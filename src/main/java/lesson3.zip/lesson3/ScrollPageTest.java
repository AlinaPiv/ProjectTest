package lesson3;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

public class ScrollPageTest {

    public static void main(String[] args) {

/*                System.setProperty(
                "webdriver.chrome.driver", "src/main/resources/chromedriver"
        );*/

        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        //options.addArguments("--headless");
        options.addArguments("start-maximized");
        options.addArguments("--remote-allow-origins=*");


        WebDriver driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        driver.get("https://www.livejournal.com");


        WebElement webElement11 = driver.findElement(By.cssSelector("s-header-item__link--login"));
        webElement11.click();
        WebElement webElement22 = driver.findElement(By.xpath(".//input[@name='user']"));
        webElement22.click();
        webElement22.sendKeys("AlinaPvr");
        WebElement webElement33 = driver.findElement(By.xpath(".//input[@name='lj_loginwidget_password']"));
        webElement33.click();
        webElement33.sendKeys("45RWt_%SDx");
        WebElement webElement44 = driver.findElement(By.name("action:login"));
        webElement44.click();


        WebElement webElement1 = driver.findElement(By.name("q"));
        WebElement webElement2 = driver.findElement(By.cssSelector("textarea.gLFyf"));
        WebElement webElement3 = driver.findElement(By.xpath(".//textarea[@name='q']"));

       /* try {
            WebElement webElementError = driver.findElement(By.name("error"));
        } catch (NoSuchElementException e){
            System.out.println(e.getSupportUrl());
        }*/

       /* List<WebElement> webElements = driver.findElements(By.name("error"));
        if(webElements.size()>1){
            //todo
        }*/

        webElement1.click();
        webElement3.sendKeys("Поиск");


        /*try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/

        // new WebDriverWait(driver, 5).until(ExpectedConditions.urlContains("google"));

        driver.navigate().to("https://google.com");

        try {
            webElement3.sendKeys("Привет");
        } catch (StaleElementReferenceException e) {
            System.out.println(e.getSupportUrl());
        }

        try {
            driver.findElement(By.xpath(".//textarea")).click();
        } catch (ElementNotInteractableException e) {
            System.out.println(e.getSupportUrl());
        }

        //Thread.sleep(10000l);
        //Завершаем работу с ресурсом
        // driver.quit();
        driver.close();


    }
}
